#!/bin/bash

if [ -z "$WINEPREFIX" ];then
	UserFolder=`echo ~`
	export WINEPREFIX="$UserFolder/.wine"
fi
if [ -d "$WINEPREFIX" ];then
	if [ -f "$WINEPREFIX/drive_c/windows/regedit.exe" ];then
		tar -zxvf ./ie7-pack.tar.gz -C $WINEPREFIX/
		wine regedit.exe /s ./ie7-registry.reg
		wine regsvr32 c:\\windows\\system32\\VGX.dll
		wine regsvr32 c:\\windows\\system32\\jscript.dll
		wine regsvr32 c:\\windows\\system32\\browseui.dll
		wine regsvr32 c:\\windows\\system32\\corpol.dll
		wine regsvr32 c:\\windows\\system32\\custsat.dll
		wine regsvr32 c:\\windows\\system32\\dxmsft.dll
		wine regsvr32 c:\\windows\\system32\\dxtrans.dll
		wine regsvr32 c:\\windows\\system32\\extmgr.dll
		wine regsvr32 c:\\windows\\system32\\hmmapi.dll
		wine regsvr32 c:\\windows\\system32\\ieaksie.dll
		wine regsvr32 c:\\windows\\system32\\ieapfltr.dll
		wine regsvr32 c:\\windows\\system32\\iedkcs32.dll
		wine regsvr32 c:\\windows\\system32\\iepeers.dll
		wine regsvr32 c:\\windows\\system32\\ieproxy.dll
		wine regsvr32 c:\\windows\\system32\\iepeers.dll
		wine regsvr32 c:\\windows\\system32\\licmgr10.dll
		wine regsvr32 c:\\windows\\system32\\mshtmled.dll
		wine regsvr32 c:\\windows\\system32\\mstime.dll
		wine regsvr32 c:\\windows\\system32\\occache.dll
		wine regsvr32 c:\\windows\\system32\\shdocvw.dll
		wine regsvr32 c:\\windows\\system32\\tdc.ocx
		wine regsvr32 c:\\windows\\system32\\urlmon.dll
		wine regsvr32 c:\\windows\\system32\\vbscript.dll
		wine regedit.exe /s ./ie7-regpatch.reg
	else
		echo "WINE PREFIX NEED INIT FIRST!"
	fi
else
	echo "WINE PREFIX IS NOT A DIRECTORY"
fi

